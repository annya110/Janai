function calculateFare() {
  const distance = document.getElementById("distance").value;
  const rate = 12; // Default fare per km
  const totalFare = distance * rate;

  document.getElementById("fareOutput").innerText = `Estimated Fare: ₹${totalFare}`;
}

// Optional: prevent form reload
document.getElementById("bookingForm").addEventListener("submit", function (e) {
  e.preventDefault();
  alert("Cab booked successfully! We'll contact you soon.");
});